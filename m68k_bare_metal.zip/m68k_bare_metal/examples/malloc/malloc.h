#ifndef _MALLOC_H_
#define _MALLOC_H_

void *malloc(size_t want);
void free(void *alloc);

#endif /* _MALLOC_H_ */
