// Pulled from musl libc

#include <ctype.h>

int toascii(int c)
{
	return c & 0x7f;
}
