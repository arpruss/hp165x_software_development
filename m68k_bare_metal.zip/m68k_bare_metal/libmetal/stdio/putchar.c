#include <printf.h>
#include <stdio.h>

int putchar(int c)
{
	_putchar((char)c);
	return c;
}
