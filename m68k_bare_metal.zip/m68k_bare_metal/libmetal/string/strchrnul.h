#ifndef STRCHRNUL_H__
#define STRCHRNUL_H__

#ifdef __cplusplus
extern "C" {
#endif //__cplusplus

// TODO: document
char* __strchrnul(const char* s, int c);

#ifdef __cplusplus
}
#endif //__cplusplus

#endif // STRCHRNUL_H__
