# need to patch QReader to support binary QR, and also the underlying zbar library

from qreader import QReader
import cv2

qreader = QReader(model_size='s',min_confidence=0.5,reencode_to=None)
image = cv2.imread("image.png")

detected = qreader.detect(image)[0]
print(qreader._decode_qr_zbar(image=image,detection_result=detected,binary=True)[0].result.data)
