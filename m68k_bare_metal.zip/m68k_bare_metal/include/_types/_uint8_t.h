#ifndef __UINT8_T_H_
#define __UINT8_T_H_

typedef unsigned char uint8_t;

#endif // __UINT8_T_H_
