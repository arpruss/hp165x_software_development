#ifndef __INT64_T_H_
#define __INT64_T_H_

typedef signed long long int64_t;

#endif // __INT64_T_H_
