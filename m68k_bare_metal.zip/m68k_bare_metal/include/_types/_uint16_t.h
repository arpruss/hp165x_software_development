#ifndef __UINT16_T_H_
#define __UINT16_T_H_

typedef unsigned short uint16_t;

#endif // __UINT16_T_H_
