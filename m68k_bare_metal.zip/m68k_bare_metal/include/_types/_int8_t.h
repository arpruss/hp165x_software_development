#ifndef __INT8_T_H_
#define __INT8_T_H_

typedef signed char int8_t;

#endif // __INT8_T_H_
