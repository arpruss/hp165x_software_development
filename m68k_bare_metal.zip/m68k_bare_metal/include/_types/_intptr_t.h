#ifndef __INTPTR_T_H_
#define __INTPTR_T_H_

typedef int intptr_t;

#endif // __INTPTR_T_H_
