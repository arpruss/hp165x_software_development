#ifndef __PTRDIFF_T_H_
#define __PTRDIFF_T_H_

typedef int ptrdiff_t;

#endif // __PTRDIFF_T_H_
