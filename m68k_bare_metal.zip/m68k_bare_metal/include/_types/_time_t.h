#ifndef __TIME_T_TYPE_DEF_H_
#define __TIME_T_TYPE_DEF_H_

typedef long time_t;
typedef long suseconds_t;

#define __suseconds_t_defined 1

#endif
