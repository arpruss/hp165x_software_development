#ifndef __INTMAX_T_H_
#define __INTMAX_T_H_

typedef long long intmax_t;

#endif // __INTMAX_T_H_
