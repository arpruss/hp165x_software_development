#ifndef __UINTPTR_T_H_
#define __UINTPTR_T_H_

typedef unsigned uintptr_t;

#endif // __UINTPTR_T_H_
