#ifndef __INT32_T_H_
#define __INT32_T_H_

typedef signed int int32_t;

#endif //__INT32_T_H_
